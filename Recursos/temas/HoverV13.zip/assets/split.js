/*  Programación Split */

  $(function() {
  var expanded = true;
  $('#one').click(function() {
    if (!expanded) {
        $(this).animate({'width': '25%'});
        $('#two').animate({'width': '25%'});
        $('#three').animate({'width': '25%'});
        $('#four').animate({'width': '25%'});
        
		setTimeout(function(){ 
				$("#oneSplit").show();
				$("#twoSplit").show();
				$("#threeSplit").show();
				$("#fourSplit").show();
				}, 1000);
        expanded = true;
    } else {
        $(this).animate({'width': '95%'});
        $('#four').animate({'width': '5%'});
        $('#two').animate({'width': '5%'});
        $('#three').animate({'width': '5%'});
        
        $("#twoSplit").hide();
        $("#threeSplit").hide();
        $("#fourSplit").hide();
      expanded = false;
    }
  });
  $('#two').click(function() {
    if (!expanded) {
        $(this).animate({'width': '25%'});
        $('#one').animate({'width': '25%'});
        $('#four').animate({'width': '25%'});
        $('#three').animate({'width': '25%'});

		setTimeout(function(){ 
				$("#oneSplit").show();
				$("#twoSplit").show();
				$("#threeSplit").show();
				$("#fourSplit").show();
				}, 1000);

        expanded = true;
    } else {
        $(this).animate({'width': '95%'});
        $('#one').animate({'width': '5%'});
        $('#four').animate({'width': '5%'});
        $('#three').animate({'width': '5%'});

        $("#oneSplit").hide();
        
        $("#threeSplit").hide();
        $("#fourSplit").hide();
      expanded = false;
    }
  });
  $('#three').click(function() {
    if (!expanded) {
        $(this).animate({'width': '25%'});
        $('#one').animate({'width': '25%'});
        $('#two').animate({'width': '25%'});
        $('#four').animate({'width': '25%'});

		setTimeout(function(){ 
				$("#oneSplit").show();
				$("#twoSplit").show();
				$("#threeSplit").show();
				$("#fourSplit").show();
				}, 1000);
        expanded = true;
    } else {
        $(this).animate({'width': '95%'});
        $('#one').animate({'width': '5%'});
        $('#two').animate({'width': '5%'});
        $('#four').animate({'width': '5%'});

        $("#oneSplit").hide();
        $("#twoSplit").hide();
        
        $("#fourSplit").hide();
      expanded = false;
    }
  });
  $('#four').click(function() {
    if (!expanded) {
        $(this).animate({'width': '25%'});
        $('#one').animate({'width': '25%'});
        $('#two').animate({'width': '25%'});
        $('#three').animate({'width': '25%'});

		setTimeout(function(){ 
				$("#oneSplit").show();
				$("#twoSplit").show();
				$("#threeSplit").show();
				$("#fourSplit").show();
				}, 1000);
        expanded = true;
    } else {
        $(this).animate({'width': '95%'});
        
        $('#one').animate({'width': '5%'});
        $('#two').animate({'width': '5%'});
        $('#three').animate({'width': '5%'});

        $("#oneSplit").hide();
        $("#twoSplit").hide();
        $("#threeSplit").hide();
        
      expanded = false;
    }
  });
});