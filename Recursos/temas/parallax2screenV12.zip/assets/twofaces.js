$('.image-bg-left-mask').on('click', function() {
  $('.wrapper').toggleClass('active-left');
});

$('.image-bg-right-mask').on('click', function() {
  $('.wrapper').toggleClass('active-right');
});

$('.btn-close', '.active-left').on('click', function() { 
    $('.wrapper').toggleClass('active-left'); 
});

$('.btn-close', '.active-right').on('click', function() { 
   $('.wrapper').toggleClass('active-right'); 
});